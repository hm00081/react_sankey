import { SankeyData } from '../types/sankey';

export const DMC09: SankeyData = {
    nodes: [],

    links: [
        {
            source: 9,
            target: 36,
            value: 1,
            valueid: '',
        }, // a[0]
        {
            source: 11,
            target: 42,
            value: 1,
            valueid: '',
        }, // a[1]
        {
            source: 36,
            target: 58,
            value: 1,
            valueid: '',
        }, // a[2]
        {
            source: 42,
            target: 58,
            value: 1,
            valueid: '',
        }, // a[3]
        {
            source: 58,
            target: 76,
            value: 1,
            valueid: '',
        }, // a[4]
        {
            source: 58,
            target: 77,
            value: 1,
            valueid: '',
        }, // a[5]
        {
            source: 58,
            target: 84,
            value: 1,
            valueid: '',
        }, // a[6]
        {
            source: 58,
            target: 93,
            value: 1,
            valueid: '',
        }, // a[7]
    ],
    status: [
        {
            status: 0,
        },
    ],
};
