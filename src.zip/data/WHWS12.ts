import { SankeyData } from '../types/sankey';

export const WHWS12: SankeyData = {
    nodes: [
        { name: 'person', type: 'Target', subtype: '0' },
        { name: 'behavior', type: 'Target', subtype: '0' },
        { name: 'psychology', type: 'Target', subtype: '0' },
        { name: 'place', type: 'Target', subtype: '0' },
        { name: 'thought', type: 'Target', subtype: '0' },
        { name: 'service', type: 'Target', subtype: '0' },
        { name: 'product', type: 'Target', subtype: '0' },
        { name: 'event', type: 'Target', subtype: '0' },
        { name: 'simple', type: 'Target', subtype: '1' },
        { name: 'composite', type: 'Target', subtype: '1' },
        { name: 'derived', type: 'Target', subtype: '1' },
        { name: 'opinion', type: 'Target', subtype: '2' },
        { name: 'appraisal', type: 'Target', subtype: '2' },
        { name: 'stance', type: 'Target', subtype: '2' },
        { name: 'attitude', type: 'Target', subtype: '2' },
        { name: 'emotion', type: 'Target', subtype: '2' },
        { name: 'writer', type: 'Target', subtype: '3' },
        { name: 'organization', type: 'Target', subtype: '3' },
        { name: 'key_player', type: 'Target', subtype: '3' },
        { name: 'public', type: 'Target', subtype: '3' },
        { name: 'community', type: 'Target', subtype: '3' },
        { name: 'birth_death', type: 'Target', subtype: '4' },
        { name: 'growth_contraction', type: 'Target', subtype: '4' },
        { name: 'continuity', type: 'Target', subtype: '4' },
        { name: 'accumulation', type: 'Target', subtype: '4' },
        { name: 'fusion_discrete', type: 'Target', subtype: '4' },
        { name: 'stable', type: 'Target', subtype: '4' },
        { name: 'repeat', type: 'Target', subtype: '4' },
        { name: 'peak_valley', type: 'Target', subtype: '4' },
        { name: 'implication', type: 'Target', subtype: '4' },
        { name: 'acceleration', type: 'Target', subtype: '4' },
        { name: 'subjectivity_detection', type: 'Intermediation', subtype: '0' },
        { name: 'emotion_cause_detection', type: 'Intermediation', subtype: '0' },
        { name: 'identifying_the_intent_of_sentiment_information', type: 'Intermediation', subtype: '0' },
        { name: 'detection_of_evidence_event_that_causes_sentiment_patterns', type: 'Intermediation', subtype: '0' },
        { name: 'argument_expression_detection', type: 'Intermediation', subtype: '0' },
        { name: 'aspect_based_sentiment_analysis', type: 'Intermediation', subtype: '0' },
        { name: 'detection_of_fake_or_deceptive_sentiment_information', type: 'Intermediation', subtype: '0' },
        { name: 'hate_speech', type: 'Intermediation', subtype: '0' },
        { name: 'opinion_summarization', type: 'Intermediation', subtype: '1' },
        { name: 'sentiment_information_description_a_multi_aspect', type: 'Intermediation', subtype: '1' },
        { name: 'emotion_detection_and_classification', type: 'Intermediation', subtype: '2' },
        { name: 'polarity_classification', type: 'Intermediation', subtype: '2' },
        { name: 'personalized_sentiment_analysis', type: 'Intermediation', subtype: '2' },
        { name: 'multilingual_and_cross_lingual_sentiment_analysis', type: 'Intermediation', subtype: '2' },
        { name: 'comparsion_of_different_sentiments', type: 'Intermediation', subtype: '3' },
        { name: 'timeline_analysis', type: 'Intermediation', subtype: '4' },
        { name: 'analysis_of_debates_comments_and_argumentation', type: 'Intermediation', subtype: '4' },
        { name: 'finding_significant', type: 'Intermediation', subtype: '4' },
        { name: 'easy_exploration_of_sentiment_information', type: 'Intermediation', subtype: '4' },
        { name: 'celestial', type: 'Representation', subtype: '0' },
        { name: 'human', type: 'Representation', subtype: '0' },
        { name: 'animal', type: 'Representation', subtype: '0' },
        { name: 'plant', type: 'Representation', subtype: '0' },
        { name: 'landscape', type: 'Representation', subtype: '0' },
        { name: 'compound', type: 'Representation', subtype: '0' },
        { name: 'metal', type: 'Representation', subtype: '0' },
        { name: 'nonmetal', type: 'Representation', subtype: '0' },
        { name: 'cell', type: 'Representation', subtype: '0' },
        { name: 'building_structure', type: 'Representation', subtype: '1' },
        { name: 'geometry', type: 'Representation', subtype: '1' },
        { name: 'picture', type: 'Representation', subtype: '1' },
        { name: 'pattern', type: 'Representation', subtype: '1' },
        { name: 'map', type: 'Representation', subtype: '1' },
        { name: 'fiber', type: 'Representation', subtype: '1' },
        { name: 'food', type: 'Representation', subtype: '1' },
        { name: 'toys_instrument', type: 'Representation', subtype: '1' },
        { name: 'software', type: 'Representation', subtype: '1' },
        { name: 'machine', type: 'Representation', subtype: '1' },
        { name: 'letter', type: 'Representation', subtype: '1' },
        { name: 'natural_phenomena', type: 'Representation', subtype: '2' },
        { name: 'behavior', type: 'Representation', subtype: '2' },
        { name: 'disaster', type: 'Representation', subtype: '2' },
        { name: 'space_time_movement', type: 'Representation', subtype: '2' },
        { name: 'machine_software_work', type: 'Representation', subtype: '3' },
        { name: 'creation_and_destruction', type: 'Representation', subtype: '3' },
        { name: 'value', type: 'Vis_var&tech', subtype: '0' },
        { name: 'color', type: 'Vis_var&tech', subtype: '0' },
        { name: 'size', type: 'Vis_var&tech', subtype: '0' },
        { name: 'shape', type: 'Vis_var&tech', subtype: '0' },
        { name: 'position', type: 'Vis_var&tech', subtype: '0' },
        { name: 'orientation', type: 'Vis_var&tech', subtype: '0' },
        { name: 'distance', type: 'Vis_var&tech', subtype: '0' },
        { name: '3d_visualization', type: 'Vis_var&tech', subtype: '1' },
        { name: 'node_link_diagram', type: 'Vis_var&tech', subtype: '1' },
        { name: 'bubble_chart', type: 'Vis_var&tech', subtype: '1' },
        { name: 'area_chart', type: 'Vis_var&tech', subtype: '1' },
        { name: 'line_plot', type: 'Vis_var&tech', subtype: '1' },
        { name: 'box_plot', type: 'Vis_var&tech', subtype: '1' },
        { name: 'pie_chart', type: 'Vis_var&tech', subtype: '1' },
        { name: 'radar_chart', type: 'Vis_var&tech', subtype: '1' },
        { name: 'tree_map', type: 'Vis_var&tech', subtype: '1' },
        { name: 'text_cloud', type: 'Vis_var&tech', subtype: '1' },
        { name: 'heatmap', type: 'Vis_var&tech', subtype: '1' },
        { name: 'scatter_plot', type: 'Vis_var&tech', subtype: '1' },
        { name: 'mds_map', type: 'Vis_var&tech', subtype: '1' },
        { name: 'parallel_coordinate', type: 'Vis_var&tech', subtype: '1' },
        { name: 'pixel_based_plot', type: 'Vis_var&tech', subtype: '1' },
        { name: 'time_oriented_visualization', type: 'Vis_var&tech', subtype: '1' },
        { name: 'spatial_based_visualization', type: 'Vis_var&tech', subtype: '1' },
    ],

    links: [
        {
            source: 152,
            target: 0,
            value: 3,
            valueid: 'repea',
        }, // a[0]
        {
            source: 152,
            target: 3,
            value: 3,
            valueid: 'repea',
        }, // a[1]
        {
            source: 152,
            target: 6,
            value: 3,
            valueid: 'repea',
        }, // a[2]
        {
            source: 152,
            target: 11,
            value: 3,
            valueid: 'repea',
        }, // a[3]
        {
            source: 0,
            target: 39,
            value: 2,
            valueid: 'repea',
        }, // a[4]
        {
            source: 3,
            target: 39,
            value: 2,
            valueid: 'repea',
        }, // a[5]
        {
            source: 6,
            target: 39,
            value: 2,
            valueid: 'repea',
        }, // a[6]
        {
            source: 0,
            target: 41,
            value: 2,
            valueid: 'repea',
        }, // a[7]
        {
            source: 3,
            target: 41,
            value: 2,
            valueid: 'repea',
        }, // a[8]
        {
            source: 6,
            target: 41,
            value: 2,
            valueid: 'repea',
        }, // a[9]
        {
            source: 0,
            target: 42,
            value: 2,
            valueid: 'repea',
        }, // a[10]
        {
            source: 3,
            target: 42,
            value: 2,
            valueid: 'repea',
        }, // a[11]
        {
            source: 6,
            target: 42,
            value: 2,
            valueid: 'repea',
        }, // a[12]
        {
            source: 0,
            target: 49,
            value: 1,
            valueid: 'repea',
        }, // a[13]
        {
            source: 3,
            target: 49,
            value: 1,
            valueid: 'repea',
        }, // a[14]
        {
            source: 6,
            target: 49,
            value: 1,
            valueid: 'repea',
        }, // a[15]
        {
            source: 11,
            target: 39,
            value: 2,
            valueid: 'repea',
        }, // a[16]
        {
            source: 11,
            target: 41,
            value: 2,
            valueid: 'repea',
        }, // a[17]
        {
            source: 11,
            target: 42,
            value: 2,
            valueid: 'repea',
        }, // a[18]
        {
            source: 11,
            target: 45,
            value: 1,
            valueid: 'repea',
        }, // a[19]
        {
            source: 39,
            target: 60,
            value: 1,
            valueid: 'repea',
        }, // a[20]
        {
            source: 41,
            target: 60,
            value: 1,
            valueid: 'repea',
        }, // a[21]
        {
            source: 42,
            target: 60,
            value: 1,
            valueid: 'repea',
        }, // a[22]
        {
            source: 39,
            target: 68,
            value: 2,
            valueid: 'repea',
        }, // a[23]
        {
            source: 41,
            target: 68,
            value: 2,
            valueid: 'repea',
        }, // a[24]
        {
            source: 42,
            target: 68,
            value: 2,
            valueid: 'repea',
        }, // a[25]
        {
            source: 49,
            target: 60,
            value: 1,
            valueid: 'repea',
        }, // a[26]
        {
            source: 49,
            target: 68,
            value: 1,
            valueid: 'repea',
        }, // a[27]
        {
            source: 39,
            target: 59,
            value: 1,
            valueid: 'repea',
        }, // a[28]
        {
            source: 41,
            target: 59,
            value: 1,
            valueid: 'repea',
        }, // a[29]
        {
            source: 42,
            target: 59,
            value: 1,
            valueid: 'repea',
        }, // a[30]
        {
            source: 45,
            target: 59,
            value: 1,
            valueid: 'repea',
        }, // a[31]
        {
            source: 60,
            target: 77,
            value: 2,
            valueid: 'repea',
        }, // a[32]
        {
            source: 60,
            target: 78,
            value: 2,
            valueid: 'repea',
        }, // a[33]
        {
            source: 68,
            target: 76,
            value: 3,
            valueid: 'repea',
        }, // a[34]
        {
            source: 68,
            target: 77,
            value: 3,
            valueid: 'repea',
        }, // a[35]
        {
            source: 68,
            target: 78,
            value: 3,
            valueid: 'repea',
        }, // a[36]
        {
            source: 59,
            target: 78,
            value: 2,
            valueid: 'repea',
        }, // a[37]
        {
            source: 59,
            target: 80,
            value: 2,
            valueid: 'repea',
        }, // a[38]
    ],
    status: [
        {
            status: 'none',
        },
    ],
};
